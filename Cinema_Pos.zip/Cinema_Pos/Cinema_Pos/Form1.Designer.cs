﻿namespace Cinema_Pos
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Panel panel1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            label2 = new Label();
            label1 = new Label();
            btnNachoMediumMenu = new Button();
            btnNachoLargeMenu = new Button();
            btnNachoDuetMenu = new Button();
            btnPCMediumMenu = new Button();
            btnPCLargeMenu = new Button();
            btnPCDuetMenu = new Button();
            richTextBox1 = new RichTextBox();
            lblTotal = new Label();
            tbnClear = new Button();
            lblBill = new Label();
            btnEndDay = new Button();
            btnDiscount = new Button();
            btnDeleteProduct = new Button();
            userPic = new PictureBox();
            panel2 = new Panel();
            label5 = new Label();
            lblRole = new Label();
            lblDiscount = new Label();
            lblDisSum = new Label();
            panel1 = new Panel();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)userPic).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(btnNachoMediumMenu);
            panel1.Controls.Add(btnNachoLargeMenu);
            panel1.Controls.Add(btnNachoDuetMenu);
            panel1.Controls.Add(btnPCMediumMenu);
            panel1.Controls.Add(btnPCLargeMenu);
            panel1.Controls.Add(btnPCDuetMenu);
            panel1.Location = new Point(9, 6);
            panel1.Margin = new Padding(0);
            panel1.Name = "panel1";
            panel1.Size = new Size(404, 488);
            panel1.TabIndex = 2;
            // 
            // label2
            // 
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Algerian", 21.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Image = Properties.Resources.nachos_2515322__1_;
            label2.ImageAlign = ContentAlignment.MiddleLeft;
            label2.Location = new Point(95, 251);
            label2.Name = "label2";
            label2.Size = new Size(198, 59);
            label2.TabIndex = 10;
            label2.Text = "Nachos";
            label2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Algerian", 21.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.Image = Properties.Resources.popcorn_2445394;
            label1.ImageAlign = ContentAlignment.MiddleLeft;
            label1.Location = new Point(73, 10);
            label1.Name = "label1";
            label1.Size = new Size(220, 59);
            label1.TabIndex = 9;
            label1.Text = "Popcorn";
            label1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // btnNachoMediumMenu
            // 
            btnNachoMediumMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnNachoMediumMenu.Image = Properties.Resources.Screenshot_2023_10_21_205847;
            btnNachoMediumMenu.ImageAlign = ContentAlignment.TopCenter;
            btnNachoMediumMenu.Location = new Point(271, 313);
            btnNachoMediumMenu.Name = "btnNachoMediumMenu";
            btnNachoMediumMenu.Size = new Size(128, 164);
            btnNachoMediumMenu.TabIndex = 8;
            btnNachoMediumMenu.Text = "Средно меню";
            btnNachoMediumMenu.TextAlign = ContentAlignment.BottomCenter;
            btnNachoMediumMenu.UseVisualStyleBackColor = true;
            btnNachoMediumMenu.Click += btnNachoMediumMenu_Click;
            // 
            // btnNachoLargeMenu
            // 
            btnNachoLargeMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnNachoLargeMenu.Image = Properties.Resources.Screenshot_2023_10_21_205822;
            btnNachoLargeMenu.ImageAlign = ContentAlignment.TopCenter;
            btnNachoLargeMenu.Location = new Point(137, 313);
            btnNachoLargeMenu.Name = "btnNachoLargeMenu";
            btnNachoLargeMenu.Size = new Size(128, 164);
            btnNachoLargeMenu.TabIndex = 7;
            btnNachoLargeMenu.Text = "Голямо меню";
            btnNachoLargeMenu.TextAlign = ContentAlignment.BottomCenter;
            btnNachoLargeMenu.UseVisualStyleBackColor = true;
            btnNachoLargeMenu.Click += btnNachoLargeMenu_Click;
            // 
            // btnNachoDuetMenu
            // 
            btnNachoDuetMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnNachoDuetMenu.Image = Properties.Resources.Screenshot_2023_10_21_205758;
            btnNachoDuetMenu.ImageAlign = ContentAlignment.TopCenter;
            btnNachoDuetMenu.Location = new Point(3, 313);
            btnNachoDuetMenu.Name = "btnNachoDuetMenu";
            btnNachoDuetMenu.Size = new Size(128, 164);
            btnNachoDuetMenu.TabIndex = 6;
            btnNachoDuetMenu.Text = "Дует меню";
            btnNachoDuetMenu.TextAlign = ContentAlignment.BottomCenter;
            btnNachoDuetMenu.UseVisualStyleBackColor = true;
            btnNachoDuetMenu.Click += btnNachoDuetMenu_Click;
            // 
            // btnPCMediumMenu
            // 
            btnPCMediumMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnPCMediumMenu.Image = Properties.Resources.Screenshot_2023_10_21_205724;
            btnPCMediumMenu.ImageAlign = ContentAlignment.TopCenter;
            btnPCMediumMenu.Location = new Point(271, 72);
            btnPCMediumMenu.Name = "btnPCMediumMenu";
            btnPCMediumMenu.Size = new Size(128, 164);
            btnPCMediumMenu.TabIndex = 5;
            btnPCMediumMenu.Text = "Средно меню";
            btnPCMediumMenu.TextAlign = ContentAlignment.BottomCenter;
            btnPCMediumMenu.UseVisualStyleBackColor = true;
            btnPCMediumMenu.Click += btnPCMediumMenu_Click;
            // 
            // btnPCLargeMenu
            // 
            btnPCLargeMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnPCLargeMenu.Image = Properties.Resources.Screenshot_2023_10_21_205704;
            btnPCLargeMenu.ImageAlign = ContentAlignment.TopCenter;
            btnPCLargeMenu.Location = new Point(137, 72);
            btnPCLargeMenu.Name = "btnPCLargeMenu";
            btnPCLargeMenu.Size = new Size(128, 164);
            btnPCLargeMenu.TabIndex = 4;
            btnPCLargeMenu.Text = "Голямо меню";
            btnPCLargeMenu.TextAlign = ContentAlignment.BottomCenter;
            btnPCLargeMenu.UseVisualStyleBackColor = true;
            btnPCLargeMenu.Click += button2_Click;
            // 
            // btnPCDuetMenu
            // 
            btnPCDuetMenu.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnPCDuetMenu.Image = Properties.Resources.Screenshot_2023_10_21_2056461;
            btnPCDuetMenu.ImageAlign = ContentAlignment.TopCenter;
            btnPCDuetMenu.Location = new Point(3, 72);
            btnPCDuetMenu.Name = "btnPCDuetMenu";
            btnPCDuetMenu.Size = new Size(128, 164);
            btnPCDuetMenu.TabIndex = 3;
            btnPCDuetMenu.Text = "Дует меню";
            btnPCDuetMenu.TextAlign = ContentAlignment.BottomCenter;
            btnPCDuetMenu.UseVisualStyleBackColor = true;
            btnPCDuetMenu.Click += btnPCDuetMenu_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            richTextBox1.Location = new Point(424, 56);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(323, 260);
            richTextBox1.TabIndex = 1;
            richTextBox1.Text = "";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblTotal.Location = new Point(679, 409);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(68, 21);
            lblTotal.TabIndex = 3;
            lblTotal.Text = "0.00 лв.";
            // 
            // tbnClear
            // 
            tbnClear.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            tbnClear.Image = Properties.Resources.payment_9165695;
            tbnClear.ImageAlign = ContentAlignment.MiddleLeft;
            tbnClear.Location = new Point(572, 454);
            tbnClear.Name = "tbnClear";
            tbnClear.Size = new Size(175, 40);
            tbnClear.TabIndex = 4;
            tbnClear.Text = "Тотал";
            tbnClear.UseVisualStyleBackColor = true;
            tbnClear.Click += tbnClear_Click;
            // 
            // lblBill
            // 
            lblBill.AutoSize = true;
            lblBill.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblBill.Location = new Point(572, 409);
            lblBill.Name = "lblBill";
            lblBill.Size = new Size(77, 21);
            lblBill.TabIndex = 5;
            lblBill.Text = "Сметка:";
            // 
            // btnEndDay
            // 
            btnEndDay.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnEndDay.Image = Properties.Resources.bill_3753033;
            btnEndDay.ImageAlign = ContentAlignment.MiddleLeft;
            btnEndDay.Location = new Point(609, 12);
            btnEndDay.Name = "btnEndDay";
            btnEndDay.Size = new Size(138, 35);
            btnEndDay.TabIndex = 8;
            btnEndDay.Text = "Приключване";
            btnEndDay.TextAlign = ContentAlignment.MiddleRight;
            btnEndDay.UseVisualStyleBackColor = true;
            btnEndDay.Click += btnEndDay_Click;
            // 
            // btnDiscount
            // 
            btnDiscount.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnDiscount.Image = Properties.Resources._10_percent_7312930__2_;
            btnDiscount.ImageAlign = ContentAlignment.MiddleLeft;
            btnDiscount.Location = new Point(638, 363);
            btnDiscount.Name = "btnDiscount";
            btnDiscount.Size = new Size(109, 43);
            btnDiscount.TabIndex = 9;
            btnDiscount.Text = "Отстъпка";
            btnDiscount.TextAlign = ContentAlignment.MiddleRight;
            btnDiscount.UseVisualStyleBackColor = true;
            btnDiscount.Click += btnDiscount_Click;
            // 
            // btnDeleteProduct
            // 
            btnDeleteProduct.Location = new Point(424, 319);
            btnDeleteProduct.Name = "btnDeleteProduct";
            btnDeleteProduct.Size = new Size(109, 35);
            btnDeleteProduct.TabIndex = 10;
            btnDeleteProduct.Text = "Изтрий";
            btnDeleteProduct.UseVisualStyleBackColor = true;
            btnDeleteProduct.Click += btnDeleteProduct_Click_1;
            // 
            // userPic
            // 
            userPic.BackgroundImage = Properties.Resources.worker_6632489;
            userPic.BackgroundImageLayout = ImageLayout.Zoom;
            userPic.Location = new Point(3, 6);
            userPic.Name = "userPic";
            userPic.Size = new Size(62, 34);
            userPic.TabIndex = 11;
            userPic.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(label5);
            panel2.Controls.Add(lblRole);
            panel2.Controls.Add(userPic);
            panel2.Location = new Point(424, 6);
            panel2.Name = "panel2";
            panel2.Size = new Size(154, 44);
            panel2.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(71, 18);
            label5.Name = "label5";
            label5.Size = new Size(65, 22);
            label5.TabIndex = 13;
            label5.Text = "ValentinP";
            label5.UseCompatibleTextRendering = true;
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Segoe UI", 8.25F, FontStyle.Italic, GraphicsUnit.Point);
            lblRole.ForeColor = SystemColors.ControlDarkDark;
            lblRole.Location = new Point(71, 6);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(41, 20);
            lblRole.TabIndex = 12;
            lblRole.Text = "Cashier";
            lblRole.UseCompatibleTextRendering = true;
            // 
            // lblDiscount
            // 
            lblDiscount.AutoSize = true;
            lblDiscount.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblDiscount.Location = new Point(572, 430);
            lblDiscount.Name = "lblDiscount";
            lblDiscount.Size = new Size(101, 21);
            lblDiscount.TabIndex = 13;
            lblDiscount.Text = "Отстъпка:";
            // 
            // lblDisSum
            // 
            lblDisSum.AutoSize = true;
            lblDisSum.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblDisSum.Location = new Point(679, 430);
            lblDisSum.Name = "lblDisSum";
            lblDisSum.Size = new Size(68, 21);
            lblDisSum.TabIndex = 14;
            lblDisSum.Text = "0.00 лв.";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(759, 505);
            Controls.Add(lblDisSum);
            Controls.Add(lblDiscount);
            Controls.Add(panel2);
            Controls.Add(btnDeleteProduct);
            Controls.Add(btnDiscount);
            Controls.Add(btnEndDay);
            Controls.Add(lblBill);
            Controls.Add(tbnClear);
            Controls.Add(lblTotal);
            Controls.Add(panel1);
            Controls.Add(richTextBox1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CinemaPos";
            Load += MainForm_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)userPic).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private RichTextBox richTextBox1;
        private Panel panel1;
        private Button btnPCMediumMenu;
        private Button btnPCLargeMenu;
        private Button btnPCDuetMenu;
        private Label label2;
        private Label label1;
        private Button btnNachoMediumMenu;
        private Button btnNachoLargeMenu;
        private Button btnNachoDuetMenu;
        private Label lblTotal;
        private Button tbnClear;
        private Label lblBill;
        private Button btnEndDay;
        private Button btnDiscount;
        private Button btnDeleteProduct;
        private PictureBox userPic;
        private Panel panel2;
        private Label lblRole;
        private Label label5;
        private Label lblDiscount;
        private Label lblDisSum;
    }
}