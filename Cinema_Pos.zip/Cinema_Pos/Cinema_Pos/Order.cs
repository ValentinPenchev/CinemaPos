﻿namespace Cinema_Pos
{
    internal class Order
    {
    }
}